<template>
  <Home />
</template>

<script setup>
  import Home from '@/components/Home.vue'
</script>
