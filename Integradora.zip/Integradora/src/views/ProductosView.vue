<template>
<Productos/>
</template>
<script setup>
import Productos from '@/components/Productos.vue'
</script>