<script setup>
import Registro from '@/components/Registro.vue' 
</script>
<template>
<Registro/>
</template>
<style scoped>
</style>