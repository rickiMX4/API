<?php
// To call this page, in the browser type:
// http://localhost/

echo 'INDEX';


/* insertar datos que vengan desde la pagina

$variable = file_get_contents("php://input");
$v2=jason_decode($variable);
$v2 se convierte en un objeto*/